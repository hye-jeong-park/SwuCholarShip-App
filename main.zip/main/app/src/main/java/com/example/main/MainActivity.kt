package com.example.main

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.*
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import java.util.*

class MainActivity : AppCompatActivity() {

    lateinit var homeBtn: ImageButton
    lateinit var infoBtn: ImageButton
    lateinit var ringBtn: ImageButton
    lateinit var myBtn: ImageButton
    lateinit var starBtn: ImageButton
    lateinit var main_month : TextView
    lateinit var btn_back : ImageView
    lateinit var btn_forward : ImageView

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        homeBtn = findViewById(R.id.homeBtn5)
        infoBtn = findViewById(R.id.infoBtn5)
        myBtn = findViewById(R.id.myBtn5)
        ringBtn = findViewById(R.id.ringBtn5)
        starBtn = findViewById(R.id.starBtn5)
        main_month = findViewById(R.id.main_month)
        btn_back = findViewById(R.id.btn_back)
        btn_forward = findViewById(R.id.btn_forward)

        var n = 0
        setFrag(n)

        btn_forward.setOnClickListener {

            if(n == 0 || n == 1){
                n++
            }

            when (n) {
                0 -> {

                    main_month.text = "8월"
                    setFrag(0)
                }
                1 -> {
                    main_month.text = "9월"
                    setFrag(1)
                }
                2-> {
                    main_month.text = "10월"
                    setFrag(2)
                }
            }
        }
        btn_back.setOnClickListener {
            if(n == 2 || n == 1){
                n--
            }

            when (n) {
                0 -> {
                    main_month.text = "8월"
                    setFrag(0)
                }
                1 -> {
                    main_month.text = "9월"
                    setFrag(1)
                }
                2-> {
                    main_month.text = "10월"
                    setFrag(2)
                }
            }
        }

        infoBtn.setOnClickListener {
            var intent = Intent(this, monthjang::class.java)
            startActivity(intent)
        }
        ringBtn.setOnClickListener {
            var intent = Intent(this, alarm::class.java)
            startActivity(intent)
        }
        main_month.setOnClickListener {
            var now_month = main_month.text

            var intent = Intent(this, monthjang::class.java)
            intent.putExtra("month",now_month)
            startActivity(intent)
        }
        starBtn.setOnClickListener {
            var intent = Intent(this, star1::class.java)
            startActivity(intent)
        }
    }

    //메뉴를 인식시키기
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }
    //메뉴 선택시 각각 해당하는 행동을 하게 해주는 코드
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item?.itemId){
            R.id.search -> {
                return true
            }
            R.id.modify -> {
                return true
            }
            R.id.notice -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.swu.ac.kr/www/noticeb.html"))
                startActivity(Intent.createChooser(intent, "Browser"))
                return true
            }
            R.id.qna -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.swu.ac.kr/www/counsel.html"))
                startActivity(Intent.createChooser(intent, "Browser"))
                return true
            }
            R.id.coachmark -> {
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    //디데이 구하는 함수
    @RequiresApi(Build.VERSION_CODES.O)
    fun fewDay(year: Int, month: Int, day: Int): Long {
        val lastDay = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DAY_OF_MONTH, day)
        }.timeInMillis

        val today = Calendar.getInstance().timeInMillis

        val fewDay = getIgnoreTimeDays(lastDay) - getIgnoreTimeDays(today)

        return fewDay / (24 * 60 * 60 * 1000)
    }

    fun getIgnoreTimeDays(time: Long): Long {
        return Calendar.getInstance().apply {
            timeInMillis = time

            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }

    //프래그먼트 넘기기
    private fun setFrag(fragnum : Int) {
        val ft = supportFragmentManager.beginTransaction()

        when (fragnum) {
            0 -> {
                ft.replace(R.id.main_frame, Frag1()).commit()
            }
            1 -> {
                ft.replace(R.id.main_frame, Frag2()).commit()
            }
            2 -> {
                ft.replace(R.id.main_frame, Frag3()).commit()
            }
        }
    }
}
