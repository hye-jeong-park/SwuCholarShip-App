package com.example.main
//알람관련페이지
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProfileAdapter2(val profileList2: ArrayList<profiles2>) : RecyclerView.Adapter<ProfileAdapter2.CustomViewHolder2>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileAdapter2.CustomViewHolder2 {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.list_item_recycle2, parent, false)
        return CustomViewHolder2(view).apply {

            itemView.setOnClickListener {
                val curPos : Int = adapterPosition
                val profile: profiles2 = profileList2.get(curPos)

                var intent = Intent(view.context, testExplain::class.java)
                view.context.startActivity(intent)
            }

            //알림 클릭을 했을 때
            ring.setOnClickListener {
                val curPos : Int = adapterPosition
                val profile: profiles2 = profileList2.get(curPos)
                var name = profile.name

                lateinit var dbManager : DBManager
                lateinit var sqlitedb : SQLiteDatabase

                dbManager = DBManager(view.context, "august_day", null, 1)
                sqlitedb = dbManager.readableDatabase

                var cursor : Cursor
                cursor = sqlitedb.rawQuery("SELECT * FROM august_day WHERE name = '"+name+"';", null)

                var x = 0
                while (cursor.moveToNext()) {
                    x = cursor.getInt((cursor.getColumnIndex("bool")))
                }

                if (x == 0){
                    ring.setImageResource(R.drawable.ic_baseline_notifications_active_24)

                    var myExam = Exam(profile.name, profile.day2,profile.value)

                    sqlitedb.execSQL("UPDATE august_day SET bool = '"+1+"' WHERE name = '"+name+"';")

                    var intent = Intent(view.context, alarm::class.java)
                    intent.putExtra("examKey", myExam)
                    view.context.startActivity(intent)
                }
                else{
                    ring.setImageResource(R.drawable.ic_baseline_notifications_24)
                    sqlitedb.execSQL("UPDATE august_day SET bool = '"+0+"' WHERE name = '"+name+"';")

                    var dbManager = DBManager_alarm(view.context, "alarm_list", null, 1)
                    sqlitedb = dbManager.readableDatabase

                    sqlitedb.execSQL("DELETE FROM alarm_list WHERE name = '"+ name +"';")

                    sqlitedb.close()
                    dbManager.close()
                }
            }

            //즐겨찾기 클릭을 했을 때
            star.setOnClickListener {
                val curPos : Int = adapterPosition
                val profile: profiles2 = profileList2.get(curPos)
                var name = profile.name

                lateinit var dbManager : DBManager
                lateinit var sqlitedb : SQLiteDatabase

                dbManager = DBManager(view.context, "august_day", null, 1)
                sqlitedb = dbManager.readableDatabase

                var cursor : Cursor
                cursor = sqlitedb.rawQuery("SELECT * FROM august_day WHERE name = '"+name+"';", null)

                var x = 0
                while (cursor.moveToNext()) {
                    x = cursor.getInt((cursor.getColumnIndex("star")))
                }

                if (x == 0){
                    star.setImageResource(R.drawable.ic_baseline_star_24)

                    var myExam = Exam(profile.name, profile.day2,profile.value)

                    sqlitedb.execSQL("UPDATE august_day SET star = '"+1+"' WHERE name = '"+name+"';")

                    cursor.close()
                    dbManager.close()
                    sqlitedb.close()

                    var intent2 = Intent(view.context, star1::class.java)
                    intent2.putExtra("examKey", myExam)
                    view.context.startActivity(intent2)
             }
                else{
                    star.setImageResource(R.drawable.no_select_star)
                    sqlitedb.execSQL("UPDATE august_day SET star = '"+0+"' WHERE name = '"+name+"';")

                    var dbManager = DBManager_star(view.context, "star_list", null, 1)
                    sqlitedb = dbManager.writableDatabase

                    sqlitedb.execSQL("DELETE FROM star_list WHERE name = '"+ name +"';")

                    sqlitedb.close()
                    dbManager.close()
                }
            }
        }
    }

    override fun onBindViewHolder(holder: ProfileAdapter2.CustomViewHolder2, position: Int) {
        holder.name.text = profileList2.get(position).name
        holder.period.text = profileList2.get(position).period
        holder.explain.text = profileList2.get(position).explain
        holder.type.text = profileList2.get(position).type
        holder.ring.setImageResource(profileList2.get(position).ring)
        holder.star.setImageResource(profileList2.get(position).star)
        holder.day2.text = profileList2.get(position).day2
        holder.value.text = profileList2.get(position).value.toString()
        holder.bool.text = profileList2.get(position).bool.toString()
        holder.star_x.text = profileList2.get(position).star_x.toString()
    }


    class CustomViewHolder2 (itemVIew : View) :RecyclerView.ViewHolder(itemVIew) {


        val name = itemVIew.findViewById<TextView>(R.id.tvs_name)
        val period = itemVIew.findViewById<TextView>(R.id.tvr_period)
        val explain = itemVIew.findViewById<TextView>(R.id.tvr_explain)
        val type = itemView.findViewById<TextView>(R.id.tvr_type)
        val ring = itemVIew.findViewById<ImageView>(R.id.ring)
        val star = itemVIew.findViewById<ImageView>(R.id.star_add)
        val day2 = itemVIew.findViewById<TextView>(R.id.day2)
        val value = itemVIew.findViewById<TextView>(R.id.value)
        val bool = itemVIew.findViewById<TextView>(R.id.bool)
        val star_x = itemVIew.findViewById<TextView>(R.id.star_x)
    }

    override fun getItemCount(): Int {
        return profileList2.size
    }

}