package com.example.main
//최현지
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProfileAdapter3(val profileList3: ArrayList<profiles3>) : RecyclerView.Adapter<ProfileAdapter3.CustomViewHolder3>() {

    lateinit var dbManager : DBManager_alarm
    lateinit var sqlitedb : SQLiteDatabase

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileAdapter3.CustomViewHolder3 {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.alarm_item_recycle, parent, false)
        return CustomViewHolder3(view).apply {
            day3.setOnClickListener {
                val curPos : Int = adapterPosition
                val profile: profiles3 = profileList3.get(curPos)

                var name = profile.name

                dbManager = DBManager_alarm(view.context, "alarm_list", null, 1)
                sqlitedb = dbManager.writableDatabase

                sqlitedb.execSQL("DELETE FROM alarm_list WHERE name = '"+ name +"';")

                var dbManager = DBManager(view.context, "august_day",null,1)
                sqlitedb = dbManager.writableDatabase

                sqlitedb.execSQL("UPDATE august_day SET bool = '"+0+"' WHERE name = '"+name+"';")

                var intent = Intent(view.context, alarm::class.java)
                view.context.startActivity(intent)

                sqlitedb.close()
                dbManager.close()
            }
        }
    }

    override fun onBindViewHolder(holder: ProfileAdapter3.CustomViewHolder3, position: Int) {
        holder.name.text = profileList3.get(position).name
        holder.value2.text = profileList3.get(position).value2.toString()
        holder.day3.text = profileList3.get(position).day3

    }


    class CustomViewHolder3 (itemVIew : View) : RecyclerView.ViewHolder(itemVIew) {

        val name = itemVIew.findViewById<TextView>(R.id.tvs_name)
        val day3 = itemVIew.findViewById<TextView>(R.id.day3)
        val value2 = itemVIew.findViewById<TextView>(R.id.value2)
    }

    override fun getItemCount(): Int {
        return profileList3.size
    }

}