package com.example.main

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProfileAdapter4(val profileList4: ArrayList<profiles4>) : RecyclerView.Adapter<ProfileAdapter4.CustomViewHolder4>() {

    lateinit var dbManager : DBManager_star
    lateinit var sqlitedb : SQLiteDatabase

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileAdapter4.CustomViewHolder4 {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.star_item_recycle, parent, false)
        return CustomViewHolder4(view).apply {
            star_del.setOnClickListener {
                val curPos : Int = adapterPosition
                val profile: profiles4 = profileList4.get(curPos)

                var name = profile.name

                dbManager = DBManager_star(view.context, "star_list", null, 1)
                sqlitedb = dbManager.writableDatabase

                sqlitedb.execSQL("DELETE FROM star_list WHERE name = '"+ name +"';")

                var dbManager = DBManager(view.context, "august_day",null,1)
                sqlitedb = dbManager.writableDatabase

                sqlitedb.execSQL("UPDATE august_day SET star = '"+0+"' WHERE name = '"+name+"';")

                var intent = Intent(view.context, star1::class.java)
                view.context.startActivity(intent)

                sqlitedb.close()
                dbManager.close()
            }
        }
    }

    override fun onBindViewHolder(holder: ProfileAdapter4.CustomViewHolder4, position: Int) {
        holder.name.text = profileList4.get(position).name
        holder.star_del.setImageResource(profileList4.get(position).star_del)
    }


    class CustomViewHolder4 (itemVIew : View) : RecyclerView.ViewHolder(itemVIew) {

        val name = itemVIew.findViewById<TextView>(R.id.tvs_name)
        val star_del = itemVIew.findViewById<ImageView>(R.id.star_del)
    }

    override fun getItemCount(): Int {
        return profileList4.size
    }

}