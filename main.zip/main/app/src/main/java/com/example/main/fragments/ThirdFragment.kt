package com.example.main.fragments

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.example.main.DBManager
import com.example.main.R
import com.example.main.databinding.FragmentFirstBinding
import com.example.main.databinding.FragmentSecBinding
import com.example.main.databinding.FragmentThirdBinding
import com.example.main.testExplain

class ThirdFragment : Fragment() {

    lateinit var dbManager : DBManager
    lateinit var sqlitedb : SQLiteDatabase

    private var _binding : FragmentThirdBinding? = null
    private val binding get() = _binding!!

    var testExplain : testExplain? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onAttach(context: Context) {
        super.onAttach(context)
        testExplain = context as testExplain
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        _binding = FragmentThirdBinding.inflate(inflater, container, false)
        var data  = (activity as testExplain).z
        binding.original.text = data
        return binding.root
    }
}
