package com.example.main
//알림관련페이지
import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.RequiresApi
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_monthjang.*
import java.util.*

class monthjang : AppCompatActivity() {
    //sql 데이터 베이스를 쓰기위해 변수 선언
    lateinit var dbManager : DBManager
    lateinit var sqlitedb : SQLiteDatabase

    //메뉴바를 위한 변수 선언
    lateinit var homeBtn: ImageButton
    lateinit var infoBtn: ImageButton
    lateinit var ringBtn: ImageButton
    lateinit var myBtn: ImageButton
    lateinit var starBtn: ImageButton

    lateinit var monthjang_back : ImageView
    lateinit var monthjang_name : TextView

    //리스트 선언
    var profileList2 =  ArrayList<profiles2>();

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_monthjang)

        homeBtn = findViewById(R.id.homeBtn5)
        infoBtn = findViewById(R.id.infoBtn5)
        myBtn = findViewById(R.id.myBtn5)
        ringBtn = findViewById(R.id.ringBtn5)
        starBtn = findViewById(R.id.starBtn5)

        monthjang_back = findViewById(R.id.monthjang_back)
        monthjang_name = findViewById(R.id.monthjang_name)

        var year = 0
        var month = 0
        var day = 0
        lateinit var last : String

        var mon = intent.getStringExtra("month")

        dbManager = DBManager(this, "august_day", null, 1)
        sqlitedb = dbManager.readableDatabase

        lateinit var cursor : Cursor
        if (mon == "8월"){
            var a = 8
            cursor = sqlitedb.rawQuery("SELECT * FROM august_day WHERE month = '"+a+"';", null)
            monthjang_name.text = "8월의 장학금"
        } else if (mon == "9월"){
            var a = 9
            cursor = sqlitedb.rawQuery("SELECT * FROM august_day WHERE month = '"+a+"';", null)
            monthjang_name.text = "9월의 장학금"
        } else {
            var a = 10
            cursor = sqlitedb.rawQuery("SELECT * FROM august_day WHERE month = '"+a+"';", null)
            monthjang_name.text = "10월의 장학금"
        }

        while (cursor.moveToNext()){
            var first = cursor.getString((cursor.getColumnIndex("name")))
            var second = cursor.getString((cursor.getColumnIndex("period")))
            var third = cursor.getString((cursor.getColumnIndex("explain")))
            var forth = cursor.getString((cursor.getColumnIndex("type")))
            var bool = cursor.getInt((cursor.getColumnIndex("bool")))
            var star = cursor.getInt((cursor.getColumnIndex("star")))

            if (bool == 0 && star == 0){
                profileList2.add(profiles2(first,second,third,forth,R.drawable.ic_baseline_notifications_24,R.drawable.no_select_star, "",0,0,0))
            }
            if (bool == 0 && star == 1){
                profileList2.add(profiles2(first,second,third,forth,R.drawable.ic_baseline_notifications_24,R.drawable.ic_baseline_star_24, "",0,0,1))
            }
            if (bool == 1 && star == 0){
                profileList2.add(profiles2(first,second,third,forth,R.drawable.ic_baseline_notifications_active_24,R.drawable.no_select_star, "",0,1,0))
            }
            if(bool == 1 && star == 1) {
                profileList2.add(profiles2(first,second,third,forth,R.drawable.ic_baseline_notifications_active_24,R.drawable.ic_baseline_star_24, "",0,1,1))
            }
        }

        var x = 0
        lateinit var cursor2 : Cursor

        if (mon == "8월"){
            var a = 8
            cursor2 = sqlitedb.rawQuery("SELECT * FROM august_day WHERE month = '"+a+"';", null)
        } else if (mon == "9월"){
            var a = 9
            cursor2 = sqlitedb.rawQuery("SELECT * FROM august_day WHERE month = '"+a+"';", null)
        } else {
            var a = 10
            cursor2 = sqlitedb.rawQuery("SELECT * FROM august_day WHERE month = '"+a+"';", null)
        }

        while (cursor2.moveToNext()){
            year = cursor2.getInt((cursor.getColumnIndex("year")))
            month = cursor2.getInt((cursor.getColumnIndex("month")))
            day = cursor2.getInt((cursor.getColumnIndex("day")))

            //디데이 구하는 코드
            val onlyDate = fewDay(year, month, day)
            val lastDate = onlyDate - 31

            if (lastDate.toInt() == 0) {
                last = "D-DAY"
            } else if (lastDate.toInt() < 0) {
                last = "신청 마감"
            } else {
                last = "D - $lastDate"
            }

            profileList2[x].day2 = last
            profileList2[x].value = lastDate.toInt()
            x++
        }

        cursor.close()
        sqlitedb.close()
        dbManager.close()
        //////////////////////////////////////////

        //profileList3 알람 눌린 순으로 정렬하기기
        profileList2.sortByDescending { it.bool }

        rvs_profile.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        rvs_profile.setHasFixedSize(true)

        rvs_profile.adapter = ProfileAdapter2(profileList2)

        homeBtn.setOnClickListener {
            var intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        ringBtn.setOnClickListener {
            var intent = Intent(this, alarm::class.java)
            startActivity(intent)
        }
        starBtn.setOnClickListener {
            var intent = Intent(this, star1::class.java)
            startActivity(intent)
        }
        monthjang_back.setOnClickListener {
            finish()
        }
    }

    //메뉴를 인식시키기
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }
    //메뉴 선택시 각각 해당하는 행동을 하게 해주는 코드
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item?.itemId){
            R.id.search -> {
                return true
            }
            R.id.modify -> {
                return true
            }
            R.id.notice -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.swu.ac.kr/www/noticeb.html"))
                startActivity(Intent.createChooser(intent, "Browser"))
                return true
            }
            R.id.qna -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.swu.ac.kr/www/counsel.html"))
                startActivity(Intent.createChooser(intent, "Browser"))
                return true
            }
            R.id.coachmark -> {
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    //디데이 구하는 함수
    @RequiresApi(Build.VERSION_CODES.O)
    fun fewDay(year: Int, month: Int, day: Int): Long {
        val lastDay = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month)
            set(Calendar.DAY_OF_MONTH, day)
        }.timeInMillis

        val today = Calendar.getInstance().timeInMillis

        val fewDay = getIgnoreTimeDays(lastDay) - getIgnoreTimeDays(today)

        return fewDay / (24 * 60 * 60 * 1000)
    }

    fun getIgnoreTimeDays(time: Long): Long {
        return Calendar.getInstance().apply {
            timeInMillis = time

            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis
    }
}