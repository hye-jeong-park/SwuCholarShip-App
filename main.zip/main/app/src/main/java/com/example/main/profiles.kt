package com.example.main

class profiles(val name: String, val period: String, val explain: String, val type: String, var day: String) {
}