package com.example.main
//알림관련페이지
class profiles2 (val name: String, val period: String, val explain: String, val type: String, var ring : Int, var star : Int, var day2: String, var value : Int, var bool : Int, var star_x: Int ) {
}