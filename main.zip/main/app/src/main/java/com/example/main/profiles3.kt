package com.example.main

class profiles3(val name: String, val day3: String, val value2 : Int) {
}