package com.example.main

import android.widget.ImageView

class profiles4(val name: String, val star_del : Int) {
}