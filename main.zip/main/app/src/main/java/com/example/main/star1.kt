package com.example.main

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_alarm.*

class star1 : AppCompatActivity() {

    //데이터 베이스 사용을 위해 변수 선언
    lateinit var dbManager : DBManager_star
    lateinit var sqlitedb : SQLiteDatabase

    //메뉴 버튼 선언
    lateinit var homeBtn: ImageButton
    lateinit var infoBtn: ImageButton
    lateinit var ringBtn: ImageButton
    lateinit var myBtn: ImageButton
    lateinit var starBtn: ImageButton

    //해시태그 선언
    lateinit var a_hash1 : TextView
    lateinit var a_hash2 : TextView
    lateinit var a_hash3 : TextView
    lateinit var a_hash4 : TextView
    lateinit var a_hash5 : TextView
    lateinit var a_hash6 : TextView


    //리스트 선언
    var profileList4 =  ArrayList<profiles4>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_star1)

        //선언 변수 메뉴 버튼과 연결시키기
        homeBtn = findViewById(R.id.homeBtn5)
        infoBtn = findViewById(R.id.infoBtn5)
        myBtn = findViewById(R.id.myBtn5)
        ringBtn = findViewById(R.id.ringBtn5)
        starBtn = findViewById(R.id.starBtn5)

        //선언 변수 해시태그와 연결시키기
        a_hash1 = findViewById(R.id.m_hash1)
        a_hash2 = findViewById(R.id.m_hash2)
        a_hash3 = findViewById(R.id.m_hash3)
        a_hash4 = findViewById(R.id.m_hash4)
        a_hash5 = findViewById(R.id.m_hash5)
        a_hash6 = findViewById(R.id.m_hash6)


        dbManager = DBManager_star(this, "star_list", null, 1)

        var a = ""

        //intent를 사용하여 알림 설정을 할 장학금 받아오기
        if (intent.hasExtra("examKey")) {
            var exam = intent.getParcelableExtra<Exam>("examKey")
            // exam변수를 초기화 할 때 자료형이 정해지지 않아서 getParcelableExtra 뒤에 <>가 생기고, 이곳에 자료형을 입력한다. */

            if (exam != null) {
                a = exam.name
            }
            sqlitedb = dbManager.writableDatabase
            sqlitedb.execSQL("INSERT INTO star_list VALUES ('" +a+"')")
        }

        dbManager = DBManager_star(this, "star_list", null, 1)
        sqlitedb = dbManager.readableDatabase

        var cursor = sqlitedb.rawQuery("SELECT * FROM star_list", null)

        while (cursor.moveToNext()){
            var first = cursor.getString((cursor.getColumnIndex("name")))

            profileList4.add(profiles4(first, R.drawable.ic_baseline_star_24))
        }

        cursor.close()
        sqlitedb.close()
        dbManager.close()

        //Adapter를 활용하여 list와 XML 이어주기
        rva_profile.layoutManager = LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
        rva_profile.setHasFixedSize(true)

        rva_profile.adapter = ProfileAdapter4(profileList4)

        //도움말 클린 버튼
        /*help_a.setOnClickListener {
            var intent = Intent(this, ::class.java)
            startActivity(intent)
        }*/

        homeBtn.setOnClickListener {
            var intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }
        infoBtn.setOnClickListener {
            var intent = Intent(this, monthjang::class.java)
            startActivity(intent)
        }
        ringBtn.setOnClickListener {
            var intent = Intent(this, alarm::class.java)
            startActivity(intent)
        }
    }

    //메뉴를 인식시키기
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }
    //메뉴 선택시 각각 해당하는 행동을 하게 해주는 코드
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item?.itemId){
            R.id.search -> {
                return true
            }
            R.id.modify -> {
                return true
            }
            R.id.notice -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.swu.ac.kr/www/noticeb.html"))
                startActivity(Intent.createChooser(intent, "Browser"))
                return true
            }
            R.id.qna -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.swu.ac.kr/www/counsel.html"))
                startActivity(Intent.createChooser(intent, "Browser"))
                return true
            }
            R.id.coachmark -> {
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}