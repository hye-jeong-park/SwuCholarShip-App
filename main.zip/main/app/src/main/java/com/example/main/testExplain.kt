package com.example.main

import android.content.Intent
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.ImageView
import androidx.viewpager2.widget.ViewPager2
import com.example.main.databinding.ActivityMainBinding
import com.example.main.fragments.FirstFragment
import com.example.main.fragments.SecFragment
import com.example.main.fragments.ThirdFragment
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.android.synthetic.main.activity_test_explain.*
import kotlinx.android.synthetic.main.fragment_first.*
import kotlinx.android.synthetic.main.fragment_sec.*

class testExplain : AppCompatActivity() {

    lateinit var binding : ActivityMainBinding
    lateinit var a : String

    lateinit var back : ImageView

    lateinit var dbManager : DBManager_ex
    lateinit var sqlitedb : SQLiteDatabase

    var x : String = ""
    var y : String = ""
    var z : String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_test_explain)
        binding = ActivityMainBinding.inflate(layoutInflater)

        var back = findViewById<ImageView>(R.id.back)

        val tabLayout=findViewById<TabLayout>(R.id.tab_layout)
        val viewPager2=findViewById<ViewPager2>(R.id.view_pager_2)

        val adapter=ViewPagerAdapter(supportFragmentManager,lifecycle)

        viewPager2.adapter=adapter

        var name = intent.getStringExtra("name")

        dbManager = DBManager_ex(this, "detail_ex", null, 1)
        sqlitedb = dbManager.readableDatabase

        var cursor : Cursor
        cursor = sqlitedb.rawQuery("SELECT * FROM detail_ex WHERE name = '"+name+"';", null)

        while (cursor.moveToNext()) {
            x = cursor.getString((cursor.getColumnIndex("detail")))
            y = cursor.getString((cursor.getColumnIndex("qualify")))
            z = cursor.getString((cursor.getColumnIndex("original")))
        }
////////////////////////////////////읽어옴

        TabLayoutMediator(tabLayout,viewPager2){tab,position->
            when(position){
                0->{
                    tab.text="상세요강"
                }
                1->{
                    tab.text="신청조건"
                }
                2->{
                    tab.text="원문공고"
                }
            }
        }.attach()

        back.setOnClickListener {
            finish()
        }
    }

    //메뉴를 인식시키기
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main, menu)
        return true
    }
    //메뉴 선택시 각각 해당하는 행동을 하게 해주는 코드
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item?.itemId){
            R.id.search -> {
                return true
            }
            R.id.modify -> {
                return true
            }
            R.id.notice -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("http://www.swu.ac.kr/www/noticeb.html"))
                startActivity(Intent.createChooser(intent, "Browser"))
                return true
            }
            R.id.qna -> {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.swu.ac.kr/www/counsel.html"))
                startActivity(Intent.createChooser(intent, "Browser"))
                return true
            }
            R.id.coachmark -> {
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }
}